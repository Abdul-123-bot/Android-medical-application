# Medication Manager

Med-Manager is a simple app that helps patients remember  to take their medication and provides tracking for the intake of the prescribed medication intake.

# Getting started
   * fork the repository
   * clone the project
   * Import the project in android studio

# Mockups

  * Check out the Medication Manager project mockups using the link below

(https://www.figma.com/file/QjhpXvrFZtpcYQYMmOsgMcpB/Med-manager?node-id=24%3A0)

# Sample project Snapshot

![alt text](https://github.com/corneliouzbett/MedicationManager/blob/master/med-res/Screenshot_20180418-200133%5B1%5D.png)

![alt text](https://github.com/corneliouzbett/MedicationManager/blob/master/med-res/Screenshot_20180418-200155%5B1%5D.png)

![alt text](https://github.com/corneliouzbett/MedicationManager/blob/master/med-res/Screenshot_20180418-200219%5B1%5D.png)

![alt text](https://github.com/corneliouzbett/MedicationManager/blob/master/med-res/Screenshot_20180418-200229%5B1%5D.png)

![alt text](https://github.com/corneliouzbett/MedicationManager/blob/master/med-res/Screenshot_20180418-200238%5B1%5D.png)


