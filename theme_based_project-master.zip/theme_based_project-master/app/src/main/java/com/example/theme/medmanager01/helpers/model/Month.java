package com.example.theme.medmanager01.helpers.model;

public class Month {
    String name;
    String numberOfMedication;

    public String getName() {
        return name;
    }

    public String getNumberOfMedication() {
        return numberOfMedication;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNumberOfMedication(String numberOfMedication) {
        this.numberOfMedication = numberOfMedication;
    }
}
