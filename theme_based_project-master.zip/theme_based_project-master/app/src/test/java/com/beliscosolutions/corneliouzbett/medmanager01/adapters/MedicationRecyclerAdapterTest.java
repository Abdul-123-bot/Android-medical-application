package com.beliscosolutions.corneliouzbett.medmanager01.adapters;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by CorneliouzBett on 15/04/2018.
 */
public class MedicationRecyclerAdapterTest {
    @Test
    public void onCreateViewHolder() throws Exception {
    }

    @Test
    public void onBindViewHolder() throws Exception {
    }

    @Test
    public void getItemCount() throws Exception {
    }

    @Test
    public void setFilter() throws Exception {
    }

}