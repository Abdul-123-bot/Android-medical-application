package com.beliscosolutions.corneliouzbett.medmanager01.helpers.model;

import org.junit.Test;

/**
 * Created by CorneliouzBett on 15/04/2018.
 */
public class UserTest {
    @Test
    public void getId() throws Exception {
    }

    @Test
    public void setId() throws Exception {
    }

    @Test
    public void getName() throws Exception {
    }

    @Test
    public void setName() throws Exception {
    }

    @Test
    public void getEmailAddress() throws Exception {
    }

    @Test
    public void setEmailAddress() throws Exception {
    }

    @Test
    public void getPassword() throws Exception {
    }

    @Test
    public void setPassword() throws Exception {
    }

}