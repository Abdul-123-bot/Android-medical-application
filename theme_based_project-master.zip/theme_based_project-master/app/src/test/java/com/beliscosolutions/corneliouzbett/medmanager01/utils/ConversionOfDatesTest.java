package com.beliscosolutions.corneliouzbett.medmanager01.utils;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by CorneliouzBett on 15/04/2018.
 */
public class ConversionOfDatesTest {
    @Test
    public void getDateFromString() throws Exception {
    }

    @Test
    public void formatDate() throws Exception {
    }

}