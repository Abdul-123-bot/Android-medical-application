package com.beliscosolutions.corneliouzbett.medmanager01.views;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by CorneliouzBett on 15/04/2018.
 */
public class MedicationCreationActivityTest {


    @Test
    public void onCreate() throws Exception {
    }

    @Test
    public void onOptionsItemSelected() throws Exception {
    }

}