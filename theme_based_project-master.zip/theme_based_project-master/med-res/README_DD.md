# Medication Manager

Fixed a bit on newer versions of AS and libraries, has achieved health, below is a list of what fixed.

ERROR: 
"compile" - obsolete replace with "implementation"
Found versions 28.0.0, 27.0.2, 26.1.0. Examples include com.android.support:animated-vector-drawable:28.0.0 and com.android.support:customtabs:27.0.2 more... - not yet decided

nav_imageprofile.png transferred to drawable from drawable24
Replaced obsolete reference version to the new one
opened from reviews the entrance is through a login and password
